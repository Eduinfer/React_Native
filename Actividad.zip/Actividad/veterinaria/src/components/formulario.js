import React from "react";
import { Modal, Text, Button } from "react-native";
const formulario = () => {
    return (
        <Modal animationType='slide' visible={false}>
        
      </Modal>
    )
}

export default formulario