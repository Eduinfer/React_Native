import { StatusBar } from 'expo-status-bar';
import { StyleSheet, SafeAreaView,Pressable, Text, View, Modal } from 'react-native';
import React, {useState} from 'react';
import formulario from './src/components/formulario';

export default function App() {

  const [modalVisible, setModalVisible]= useState([false])
  console.log(modalVisible)

  setTimeout(()=>{
    setModalVisible(true)
  }, 30);

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.titulo}>
      Administrador de Citas <Text style = {styles.tituloBold}>Veterinaria</Text>
      </Text>
      <Pressable onPress = {()=>setModalVisible(true)}
      style={styles.btnNuevaCita}>
      <Text style={styles.btnTextNuevasCitas}>Nueva Cita</Text>
      </Pressable>
      <formulario
      modalVisible={modalVisible}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
    padding: 8,

  },
  titulo: {
    margin: 24,
    fontSize: 30,
    textTransform: 'uppercase',
    // fontWeight: 600,
    color: '#374151',
    textAling: 'center'
  },
  tituloBold: {
    color: '#6D28D9'
  },
  btnNuevaCita: {
    backgroundColor: '#6D28D9',
    padding: 15,
    marginTop: 30,
    marginLeft: 20,
    marginRight: 20,
    borderRadius: 10
  },
  btnTextNuevasCitas: {
    textAlign: 'center',
    color: '#fff',
    fontSize: 20,
    // fontWeight: 900,
    textTransform: 'uppercase'
  }

});

